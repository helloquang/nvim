<?php

declare(strict_types=1);

namespace App;

use App\Handler\ContainerLoaderRuntimeFactory;
use App\Handler\FormFactoryBuilder;
use App\Handler\FormRendererFactory;
use App\Handler\FormRuntimeLoader;
use App\Handler\TranslationExtensionFactory;
use App\Handler\TranslatorFactory;
use App\Handler\TwigRendererEngineFactory;
use Symfony\Bridge\Twig\Extension\FormExtension;
use Symfony\Bridge\Twig\Extension\TranslationExtension;
use Symfony\Bridge\Twig\Form\TwigRendererEngine;
use Symfony\Component\Form\FormFactory;
use Symfony\Component\Form\FormRenderer;
use Symfony\Component\Security\Csrf\CsrfTokenManager;
use Symfony\Component\Translation\Translator;
use Twig\RuntimeLoader\ContainerRuntimeLoader;

/**
 * The configuration provider for the App module
 *
 * @see https://docs.laminas.dev/laminas-component-installer/
 */
class ConfigProvider
{
    /**
     * Returns the configuration array
     *
     * To add a bit of a structure, each section is defined in a separate
     * method which returns an array with its configuration.
     */
    public function __invoke(): array
    {
        return [
            'dependencies' => $this->getDependencies(),
            'templates'    => $this->getTemplates(),
        ];
    }

    /**
     * Returns the container dependencies
     */
    public function getDependencies(): array
    {
        return [
            'invokables' => [
                Handler\PingHandler::class => Handler\PingHandler::class,
				CsrfTokenManager::class,
            ],
            'factories'  => [
				ContainerRuntimeLoader::class => ContainerLoaderRuntimeFactory::class,
                Handler\HomePageHandler::class => Handler\HomePageHandlerFactory::class,
                FormExtension::class => Handler\FormExtensionFactory::class,
				TranslationExtension::class => TranslationExtensionFactory::class,
				FormRenderer::class => FormRendererFactory::class,
				TwigRendererEngine::class => TwigRendererEngineFactory::class,
				Translator::class => TranslatorFactory::class,
				FormFactory::class => FormFactoryBuilder::class
            ],
        ];
    }

    /**
     * Returns the templates configuration
     */
    public function getTemplates(): array
    {
        return [
            'paths' => [
                'app'    => [__DIR__ . '/../templates/app'],
                'error'  => [__DIR__ . '/../templates/error'],
                'layout' => [__DIR__ . '/../templates/layout'],
				 __DIR__ . '/../templates/forms',
            ],
			'extensions' => [
				FormExtension::class,
				TranslationExtension::class,
			],
			'runtime_loaders' => [
				ContainerRuntimeLoader::class,
			]
        ];
    }
}
