<?php

namespace App\Handler;

use Psr\Container\ContainerInterface;
use Symfony\Bridge\Twig\Form\TwigRendererEngine;
use Symfony\Component\Form\FormRenderer;
use Symfony\Component\Security\Csrf\CsrfTokenManager;

class FormRendererFactory {
	public function __invoke(ContainerInterface $container) {
		$engine = $container->get(TwigRendererEngine::class);
		$csrfTokenManager = $container->get(CsrfTokenManager::class);
		return new FormRenderer($engine, $csrfTokenManager);
	}
}
