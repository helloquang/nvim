<?php

namespace App\Handler;

use Psr\Container\ContainerInterface;
use Symfony\Component\Translation\Loader\PhpFileLoader;
use Symfony\Component\Translation\Translator;

class TranslatorFactory {
	public function __invoke(ContainerInterface $container) {
		$config = $container->get('config');
		$translatorConfig = $config['translator'];
		$translator = new Translator($translatorConfig['locale']);

		$filePatterns = $translatorConfig['translation_file_patterns'];

		$loader = new PhpFileLoader();
		$translator->addLoader('phpArray', $loader);
		foreach ($filePatterns as $pattern) {
			$baseDir = rtrim($pattern['base_dir'], "/");
			$filename = $baseDir . '/' . sprintf($pattern['pattern'], $translatorConfig['locale']);
			$translator->addResource($pattern['type'], $filename, $translatorConfig['locale'], $pattern['text_domain']);
		}

		return $translator;
	}
}
