<?php

namespace App\Handler;

use Psr\Container\ContainerInterface;
use Symfony\Bridge\Twig\Extension\FormExtension;
use Symfony\Component\Translation\Translator;

class FormExtensionFactory {
	public function __invoke(ContainerInterface $container) {
		$translator = $container->get(Translator::class);
		return new FormExtension($translator);
	}
}
