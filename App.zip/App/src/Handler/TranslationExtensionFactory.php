<?php

namespace App\Handler;

use Psr\Container\ContainerInterface;
use Symfony\Bridge\Twig\Extension\FormExtension;
use Symfony\Bridge\Twig\Extension\TranslationExtension;
use Symfony\Component\Translation\Loader\ArrayLoader;
use Symfony\Component\Translation\Loader\PhpFileLoader;
use Symfony\Component\Translation\Translator;

class TranslationExtensionFactory {
	public function __invoke(ContainerInterface $container) {
		$translator = $container->get(Translator::class);
		return new TranslationExtension($translator);
	}
}
