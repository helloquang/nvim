<?php

namespace App\Handler;

use Psr\Container\ContainerInterface;
use Symfony\Component\Form\Extension\Csrf\CsrfExtension;
use Symfony\Component\Form\Extension\Validator\ValidatorExtension;
use Symfony\Component\Form\Forms;
use Symfony\Component\Security\Csrf\CsrfTokenManager;
use Symfony\Component\Translation\Translator;
use Symfony\Component\Validator\Validation;

class FormFactoryBuilder {
	public function __invoke(ContainerInterface $container) {
		$translator = $container->get(Translator::class);
		$validator =  Validation::createValidatorBuilder()->setTranslator($translator)->setTranslationDomain('validators')->getValidator();
		$validationExtension = new ValidatorExtension($validator);
		$csrfExtension = new CsrfExtension($container->get(CsrfTokenManager::class));
		
		$builder = Forms::createFormFactoryBuilder()
			->addExtension($csrfExtension)
			->addExtension($validationExtension);
		return $builder->getFormFactory();
	}
}
