<?php

declare(strict_types=1);

namespace App\Handler;

use Chubbyphp\Container\MinimalContainer;
use DI\Container as PHPDIContainer;
use Laminas\Diactoros\Response\HtmlResponse;
use Laminas\Diactoros\Response\JsonResponse;
use Laminas\ServiceManager\ServiceManager;
use Mezzio\LaminasView\LaminasViewRenderer;
use Mezzio\Plates\PlatesRenderer;
use Mezzio\Router\FastRouteRouter;
use Mezzio\Router\LaminasRouter;
use Mezzio\Router\RouterInterface;
use Mezzio\Template\TemplateRendererInterface;
use Mezzio\Twig\TwigRenderer;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\Form\Extension\Core\Type\FormType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Validator\ValidatorExtension;
use Symfony\Component\Form\Form;
use Symfony\Component\Form\FormFactory;
use Symfony\Component\Form\Forms;
use Symfony\Component\Validator\Validation;

final class HomePageHandler implements RequestHandlerInterface
{
    public function __construct(
        private readonly string $containerName,
        private readonly RouterInterface $router,
        private readonly TemplateRendererInterface $template,
        private readonly FormFactory $formFactory,
    ) {
    }

    public function handle(ServerRequestInterface $request): ResponseInterface
    {
		$form = $this->formFactory->create(LoginForm::class);
		if ($request->getMethod() === "POST") {
			$postData = $request->getParsedBody();
			$form->submit($postData[$form->getName()]);
			if ($form->isValid()) {
				var_dump('valid');
				die;
			}
		}
		return new HtmlResponse($this->template->render('app::form', [
			'form' => $form->createView()
		]));
    }
}
