<?php

namespace App\Handler;

use Psr\Container\ContainerInterface;
use Twig\RuntimeLoader\ContainerRuntimeLoader;

class ContainerLoaderRuntimeFactory {
	public function __invoke(ContainerInterface $container) {
		return new ContainerRuntimeLoader($container);
	}
}
