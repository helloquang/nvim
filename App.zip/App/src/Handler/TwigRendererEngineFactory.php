<?php

namespace App\Handler;

use Psr\Container\ContainerInterface;
use Symfony\Bridge\Twig\Form\TwigRendererEngine;
use Twig\Environment;

class TwigRendererEngineFactory {
	public function __invoke(ContainerInterface $container) {
		$env = $container->get(Environment::class);
		return new TwigRendererEngine(['form_theme_layout.html.twig'], $env);
	}
}
